import React, { useState } from 'react';
import { BriefcaseIcon, SearchIcon, UserCheckIcon, ClockIcon, ArrowRightIcon, CheckCircleIcon, BuildingIcon, GraduationCapIcon, CalendarClockIcon, WalletIcon } from 'lucide-react';
import RegistrationForm from './components/RegistrationForm';

function App() {
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm fixed w-full z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <ClockIcon className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">SPOTJOB</span>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <a href="#how-it-works" className="text-gray-700 hover:text-blue-600">How it Works</a>
              <a href="#employers" className="text-gray-700 hover:text-blue-600">For Employers</a>
              <a href="#employees" className="text-gray-700 hover:text-blue-600">For Employees</a>
              <button
                onClick={() => setShowForm(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-12 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                <span className="block">Work Without</span>
                <span className="block text-blue-600">Barriers</span>
              </h1>
              <p className="mt-3 text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl">
                SPOTJOB is India's first truly flexible job platform. No degree requirements, no skill barriers, just opportunities for everyone. Work on your terms, earn on your schedule.
              </p>
              <div className="mt-5 sm:flex sm:justify-start md:mt-8">
                <button
                  onClick={() => setShowForm(true)}
                  className="flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10"
                >
                  Start Your Journey <ArrowRightIcon className="ml-2 h-5 w-5" />
                </button>
              </div>
            </div>
            <div className="hidden md:block">
              <img
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="People working"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why SPOTJOB Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-extrabold text-center text-gray-900 mb-12">
            Why Choose SPOTJOB?
          </h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <GraduationCapIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No Degree Required</h3>
              <p className="text-gray-600">Find jobs without qualifications. Your skills and willingness matter more.</p>
            </div>
            <div className="text-center p-6">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <CalendarClockIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Flexible Hours</h3>
              <p className="text-gray-600">Work when you want. Choose jobs that fit your schedule.</p>
            </div>
            <div className="text-center p-6">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <WalletIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Earn Your Way</h3>
              <p className="text-gray-600">Multiple jobs, better earnings. You control your income.</p>
            </div>
            <div className="text-center p-6">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <BuildingIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Diverse Options</h3>
              <p className="text-gray-600">From corporate to delivery jobs, find what suits you best.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-extrabold text-center text-gray-900 mb-12">
            How It Works
          </h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <UserCheckIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Sign Up</h3>
              <p className="text-gray-600">Quick registration with basic details</p>
            </div>
            <div className="text-center p-6">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <SearchIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">2. Find Jobs</h3>
              <p className="text-gray-600">Browse jobs that match your preferences</p>
            </div>
            <div className="text-center p-6">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <ClockIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Choose Time</h3>
              <p className="text-gray-600">Pick jobs that fit your schedule</p>
            </div>
            <div className="text-center p-6">
              <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <BriefcaseIcon className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">4. Start Working</h3>
              <p className="text-gray-600">Begin earning on your terms</p>
            </div>
          </div>
        </div>
      </section>

      {/* For Employers Section */}
      <section id="employers" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-extrabold text-gray-900 mb-8">
                For Employers
              </h2>
              <div className="space-y-4">
                {[
                  "Post jobs instantly based on your needs",
                  "Hire part-timers, freelancers, or temporary workers",
                  "Set your own job requirements and work hours",
                  "No long-term commitments required",
                  "Access a diverse pool of candidates",
                  "Quick and hassle-free hiring process"
                ].map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-2 bg-gray-50 p-4 rounded-lg">
                    <CheckCircleIcon className="h-5 w-5 text-green-500" />
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="Employer and employee discussion"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* For Employees Section */}
      <section id="employees" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <img
                src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="People working flexibly"
                className="rounded-lg shadow-xl"
              />
            </div>
            <div className="order-1 md:order-2">
              <h2 className="text-3xl font-extrabold text-gray-900 mb-8">
                For Job Seekers
              </h2>
              <div className="space-y-4">
                {[
                  "Find jobs that match your schedule",
                  "No experience or degree requirements",
                  "Work multiple jobs simultaneously",
                  "Choose from various job types",
                  "Earn based on your availability",
                  "Simple and quick application process"
                ].map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-2 bg-white p-4 rounded-lg">
                    <CheckCircleIcon className="h-5 w-5 text-green-500" />
                    <span className="text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Registration Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-gray-900">Get Started with SPOTJOB</h2>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>
            <RegistrationForm onClose={() => setShowForm(false)} />
          </div>
        </div>
      )}
    </div>
  );
}

export default App;