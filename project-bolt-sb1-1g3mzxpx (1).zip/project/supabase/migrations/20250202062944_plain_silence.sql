/*
  # Create job seekers table

  1. New Tables
    - `job_seekers`
      - `id` (uuid, primary key)
      - `full_name` (text)
      - `email` (text, unique)
      - `phone` (text)
      - `location` (text)
      - `availability` (text array)
      - `preferred_work` (text array)
      - `experience` (text)
      - `expected_pay` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `job_seekers` table
    - Add policy for authenticated users to read all entries
    - Add policy for anyone to insert their own data
*/

CREATE TABLE IF NOT EXISTS job_seekers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  location text NOT NULL,
  availability text[] NOT NULL,
  preferred_work text[] NOT NULL,
  experience text,
  expected_pay text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE job_seekers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert job seekers data"
  ON job_seekers
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view all job seekers"
  ON job_seekers
  FOR SELECT
  TO authenticated
  USING (true);